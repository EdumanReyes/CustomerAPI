﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


using Microsoft.EntityFrameworkCore;
using CustomerAPI.Models;
using System;
using Microsoft.AspNetCore.Cors;
namespace CustomerAPI.Controllers
{
    [EnableCors("ReglasCors")]
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        public readonly PruebaContext _dbcontext;

        public CustomerController(PruebaContext _context)
        {
            _dbcontext = _context;
        }

        [HttpPost]
        [Route("Save")]
        public IActionResult Save([FromBody] Customer objeto )
        {
            try
            {
                _dbcontext.Customers.Add(objeto);
                _dbcontext.SaveChanges();

                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok"});
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status200OK, new { mensaje = ex.Message});
            }
        }

        [HttpPut]
        [Route("Update")]
        public IActionResult Update([FromBody] Customer objeto)
        {
            Customer oCustomer = _dbcontext.Customers.Find(objeto.Id);
            if (oCustomer == null)
            {
                return BadRequest("Producto no encontrado");
            }
            try
            {   oCustomer.Edad = objeto.Edad is null? oCustomer.Edad : objeto.Edad;
                oCustomer.Nombre = objeto.Nombre is null ? oCustomer.Nombre : objeto.Nombre;
                oCustomer.Email = objeto.Email is null ? oCustomer.Email : objeto.Email;

                _dbcontext.Customers.Update(oCustomer);
                _dbcontext.SaveChanges();

                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status200OK, new { mensaje = ex.Message });
            }
        }

        [HttpDelete]
        [Route("Delete/{idCustomer:int}")]
        public IActionResult Delete(int idCustomer) {
            Customer oCustomer = _dbcontext.Customers.Find(idCustomer);
            if (oCustomer == null)
            {
                return BadRequest("Producto no encontrado");
            }
            try
            { 
                _dbcontext.Customers.Remove(oCustomer);
                _dbcontext.SaveChanges();

                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok" });
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status200OK, new { mensaje = ex.Message });
            }
        }

        [HttpGet]
        [Route("GetById/{idCustomer:int}")]
        public IActionResult GetById(int idCustomer)
        {
            Customer oCustomer = _dbcontext.Customers.Find(idCustomer);
            if (oCustomer == null) {
                return BadRequest("Producto no encontrado");
            }
            try
            {
                 return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", response = oCustomer});
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status200OK, new { mensaje = ex.Message, response = oCustomer });
            }
        }


        [HttpGet]
        [Route("GetList")]
        public IActionResult Lista() {
            List<Customer> lista = new List<Customer>();

            try {
                lista = _dbcontext.Customers.ToList();
                return StatusCode(StatusCodes.Status200OK, new { mensaje = "ok", response = lista });
            }
            catch (Exception ex) {
                return StatusCode(StatusCodes.Status200OK, new { mensaje = ex.Message, response = lista });
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;

namespace CustomerAPI.Models;

public partial class Customer
{
    public int Id { get; set; }

    public int? Edad { get; set; }

    public string? Nombre { get; set; }

    public string? Email { get; set; }
}
